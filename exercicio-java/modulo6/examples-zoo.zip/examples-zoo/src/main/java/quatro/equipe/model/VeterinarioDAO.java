package quatro.equipe.model;

import java.util.List;

public class VeterinarioDAO implements DAO<Veterinario>{


    @Override
    public void salva(Veterinario objeto) {

    }

    @Override
    public void salva(List<Veterinario> listagem) {

    }

    @Override
    public Veterinario obter(String id) {
        return null;
    }

    @Override
    public List<Veterinario> listagem() {
        return null;
    }
}
