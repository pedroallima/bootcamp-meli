package quatro.equipe.model;

import java.util.List;

public class PacienteDAO implements DAO<Paciente> {

    @Override
    public void salva(Paciente objeto) {

    }

    @Override
    public void salva(List<Paciente> listagem) {

    }

    @Override
    public Paciente obter(String id) {
        return null;
    }

    @Override
    public List<Paciente> listagem() {
        return null;
    }
}
